# YouTube API Proxy — La Morada del Nuevo Tango

Proxy serverless para ocultar la API key de YouTube.
Se deploya en Vercel (gratis) y tu sitio en GitHub Pages lo consume.

---

## Paso 1 — Revocar la API key expuesta

1. Ir a https://console.cloud.google.com/
2. APIs y servicios → Credenciales
3. Hacer clic en tu API key → REGENERAR (o eliminar y crear una nueva)
4. Copiar la nueva key — la vas a necesitar en el Paso 3

---

## Paso 2 — Deployar este proxy en Vercel

Opción A: desde la CLI
```bash
npm i -g vercel
cd yt-proxy
vercel
```

Opción B: desde el dashboard de Vercel
1. Crear un nuevo repositorio en GitHub y subir esta carpeta `yt-proxy`
2. En vercel.com → Add New Project → importar ese repo
3. Hacer clic en Deploy

---

## Paso 3 — Agregar la API key como variable de entorno en Vercel

1. En tu proyecto de Vercel → Settings → Environment Variables
2. Agregar:
   - Name:  YOUTUBE_API_KEY
   - Value: (tu nueva API key de Google)
   - Environments: Production ✓, Preview ✓
3. Guardar y hacer Redeploy

---

## Paso 4 — Configurar el dominio permitido (CORS)

En ambos archivos `api/youtube-search.js` y `api/youtube-playlist.js`,
reemplazá esta línea:

```js
res.setHeader('Access-Control-Allow-Origin', 'https://TU-USUARIO.github.io');
```

con la URL real de tu sitio, por ejemplo:
```js
res.setHeader('Access-Control-Allow-Origin', 'https://lamoradadeltango.github.io');
```

Esto asegura que solo TU sitio pueda usar el proxy.

---

## Paso 5 — Actualizar index.html

Reemplazá en tu index.html:

### En getLatestVideos():
```js
// ANTES
const baseUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${channelId}&maxResults=${MAX_RESULTS}&order=date&type=video&key=${API_KEY}`;
const [resMedium, resLong] = await Promise.all([
  fetch(baseUrl + '&videoDuration=medium'),
  fetch(baseUrl + '&videoDuration=long')
]);

// DESPUÉS
const PROXY = 'https://TU-PROYECTO.vercel.app'; // <-- tu URL de Vercel
const [resMedium, resLong] = await Promise.all([
  fetch(`${PROXY}/api/youtube-search?channelId=${channelId}&maxResults=${MAX_RESULTS}&videoDuration=medium`),
  fetch(`${PROXY}/api/youtube-search?channelId=${channelId}&maxResults=${MAX_RESULTS}&videoDuration=long`)
]);
```

### En loadPlaylistVideos():
```js
// ANTES
const url = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=4&playlistId=${playlistId}&key=${API_KEY}`;

// DESPUÉS
const url = `${PROXY}/api/youtube-playlist?playlistId=${playlistId}&maxResults=4`;
```

### Eliminar la API key del HTML:
```js
// BORRAR esta línea:
const API_KEY = 'AIzaSyB9U-2cwKb00WU-L1d57megS5-qwVrgkJw';
```

---

## Resultado final

- Tu API key vive solo en Vercel (variable de entorno, nunca visible)
- Solo tu dominio de GitHub Pages puede llamar al proxy (CORS)
- El código fuente público ya no contiene ninguna credencial
