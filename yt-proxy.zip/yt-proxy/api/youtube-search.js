export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', 'https://TU-USUARIO.github.io'); // <-- cambiá esto
  res.setHeader('Access-Control-Allow-Methods', 'GET');

  const { channelId, maxResults = 6, videoDuration } = req.query;

  if (!channelId) {
    return res.status(400).json({ error: 'channelId es requerido' });
  }

  const params = new URLSearchParams({
    part: 'snippet',
    channelId,
    maxResults,
    order: 'date',
    type: 'video',
    key: process.env.YOUTUBE_API_KEY,
  });

  if (videoDuration) params.append('videoDuration', videoDuration);

  try {
    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/search?${params}`
    );
    const data = await response.json();
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: 'Error al contactar la API de YouTube' });
  }
}
