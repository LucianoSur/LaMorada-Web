export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', 'https://TU-USUARIO.github.io'); // <-- cambiá esto
  res.setHeader('Access-Control-Allow-Methods', 'GET');

  const { playlistId, maxResults = 4 } = req.query;

  if (!playlistId) {
    return res.status(400).json({ error: 'playlistId es requerido' });
  }

  const params = new URLSearchParams({
    part: 'snippet',
    playlistId,
    maxResults,
    key: process.env.YOUTUBE_API_KEY,
  });

  try {
    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/playlistItems?${params}`
    );
    const data = await response.json();
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: 'Error al contactar la API de YouTube' });
  }
}
